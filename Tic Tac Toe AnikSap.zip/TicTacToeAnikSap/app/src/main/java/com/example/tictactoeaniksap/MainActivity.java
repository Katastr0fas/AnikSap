package com.example.tictactoeaniksap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView imageicon1,imageicon2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageicon1 = findViewById(R.id.icon_logo1);
        imageicon2 = findViewById(R.id.icon_logo2);
    }

    public void StartGame1(View view) {
        Intent intent = new Intent(MainActivity.this, TicTacToe.class);
        startActivity(intent);
        finish();
    }





    public void StartGame2(View view) {
    }
}