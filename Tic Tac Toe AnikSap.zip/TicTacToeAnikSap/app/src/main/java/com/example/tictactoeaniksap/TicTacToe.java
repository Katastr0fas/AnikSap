package com.example.tictactoeaniksap;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TicTacToe extends AppCompatActivity {
    Button button1,button2,button3,button4,button5,button6,button7,button8,button9;
    String Krest, nol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tic_tac_toe);
        Krest = "x";
        nol = "0";
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);
    }

    public void clcbtn1(View view) {
        button1.setText(Krest);

    }
    public void clcbtn2(View view) {
        button2.setText(Krest);
    }
    public void clcbtn3(View view) {
        button3.setText(Krest);
    }
    public void clcbtn4(View view) {
        button4.setText(Krest);
    }
    public void clcbtn5(View view) {
        button5.setText(Krest);
    }
    public void clcbtn6(View view) {
        button6.setText(Krest);
    }
    public void clcbtn7(View view) {
        button7.setText(Krest);
    }
    public void clcbtn8(View view) {
        button8.setText(Krest);
    }
    public void clcbtn9(View view) {
        button9.setText(Krest);
    }
}